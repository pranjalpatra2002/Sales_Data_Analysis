# 🛍️ Sales Data Analysis & Dashboard

## 📌 Project Overview
This project analyzes the **Superstore Sales Dataset** to uncover trends in product performance, regional profits, and monthly revenue changes. The goal is to practice data analysis techniques and deliver actionable insights using visualization tools.

## 🧰 Tools Used
- Python (pandas, matplotlib)
- Jupyter Notebook / VS Code
- Superstore Dataset (from Kaggle)

## 📊 Key Questions Answered
- What are the top-performing product categories?
- Which region generates the most profit?
- What are the monthly sales trends?
- Who are the top customers by revenue?

## 📈 Visualizations Included
- Line Chart: Monthly Sales Trend
- Bar Chart: Sales by Product Sub-Category
- Pie Chart: Regional Sales Distribution

## 💡 Key Insights
- The Technology category generated the highest revenue.
- West and East regions contribute the most to overall sales.
- Sales peak in November and December, indicating strong Q4 performance.

## 📂 Project Structure
```
Sales-Data-Analysis-Dashboard/
├── superstore_sales.csv
├── analysis.py
├── charts/
│   ├── monthly_sales_trend.png
│   ├── sales_by_subcategory.png
│   └── region_sales_pie.png
└── README.md
```

## ✅ How to Run
1. Clone the repository or download the ZIP.
2. Install Python requirements:
   pip install pandas matplotlib
3. Run the script:
   python analysis.py

## 🔗 Dataset Source
[Superstore Sales Dataset - Kaggle](https://www.kaggle.com/datasets/vivek468/superstore-dataset-final)
